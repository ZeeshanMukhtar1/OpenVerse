package com.example.pakcityguide;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class welcomescreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcomescreen);
    }
}
package com.example.music_player.album;

public class AlbumStructer {
    int img;
    String path, Artist;
    public AlbumStructer (int img, String path, String Artist){

        this.img = img;
        this.path = path;
        this.Artist = Artist;
    }
}
